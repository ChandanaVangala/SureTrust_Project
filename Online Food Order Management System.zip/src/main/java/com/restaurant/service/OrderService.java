package com.restaurant.service;

import com.restaurant.model.*;
import com.restaurant.repository.OrderRepository;
import com.restaurant.repository.OrderItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private OrderItemRepository orderItemRepository;

    @Autowired
    private MenuService menuService;

    @Autowired
    private TableService tableService;

    public Order createOrder(User customer, Long tableId, String specialInstructions) {
        try {
            // Validate input
            if (customer == null) {
                throw new RuntimeException("Customer cannot be null");
            }
            
            Order order = new Order();
            order.setCustomer(customer);
            
            // Initialize required fields
            order.setOrderTime(java.time.LocalDateTime.now());
            order.setStatus(Order.OrderStatus.PENDING);
            order.setTotalAmount(java.math.BigDecimal.ZERO);
            order.setOvertimeCharges(java.math.BigDecimal.ZERO);
            order.setOrderItems(new java.util.ArrayList<>());
            
            // Set special instructions if provided
            if (specialInstructions != null && !specialInstructions.trim().isEmpty()) {
                order.setSpecialInstructions(specialInstructions.trim());
            }
            
            // Set table if provided
            if (tableId != null) {
                Optional<RestaurantTable> tableOpt = tableService.getTableById(tableId);
                if (tableOpt.isPresent()) {
                    order.setTable(tableOpt.get());
                } else {
                    throw new RuntimeException("Table not found with ID: " + tableId);
                }
            }
            
            // Save and return the order
            Order savedOrder = orderRepository.save(order);
            return savedOrder;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to create order: " + e.getMessage(), e);
        }
    }

//    public Order addItemToOrder(Long orderId, Long menuItemId, Integer quantity, String notes) {
//        try {
//            // Validate input parameters
//            if (orderId == null || menuItemId == null || quantity == null || quantity <= 0) {
//                throw new RuntimeException("Invalid input parameters");
//            }
//            
//            Optional<Order> orderOpt = orderRepository.findById(orderId);
//            if (!orderOpt.isPresent()) {
//                throw new RuntimeException("Order not found with ID: " + orderId);
//            }
//            
//            Optional<MenuItem> menuItemOpt = menuService.getMenuItemById(menuItemId);
//            if (!menuItemOpt.isPresent()) {
//                throw new RuntimeException("Menu item not found with ID: " + menuItemId);
//            }
//
//            Order order = orderOpt.get();
//            MenuItem menuItem = menuItemOpt.get();
//
//            if (!menuItem.isAvailable()) {
//                throw new RuntimeException("Menu item '" + menuItem.getName() + "' is not available");
//            }
//
//            // Create and configure order item
//            OrderItem orderItem = new OrderItem(order, menuItem, quantity);
//            if (notes != null && !notes.trim().isEmpty()) {
//                orderItem.setNotes(notes.trim());
//            }
//            
//            // Initialize order items list if null
//            if (order.getOrderItems() == null) {
//                order.setOrderItems(new java.util.ArrayList<>());
//            }
//            
//            // Add item to order
//            order.addOrderItem(orderItem);
//            
//            // Save order item first
//            OrderItem savedOrderItem = orderItemRepository.save(orderItem);
//            
//            // Save and return updated order
//            Order savedOrder = orderRepository.save(order);
//            
//            return savedOrder;
//        } catch (Exception e) {
//            e.printStackTrace();
//            throw new RuntimeException("Failed to add item to order: " + e.getMessage(), e);
//        }
//    }
    
    @Transactional
    public void addItemToOrder(Long orderId, Long menuItemId, int quantity, String notes) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new IllegalArgumentException("Order not found"));

        MenuItem menuItem = menuService.getMenuItemById(menuItemId)
                .orElseThrow(() -> new IllegalArgumentException("Menu item not found"));

        if (!menuItem.isAvailable()) {
            throw new IllegalStateException("Menu item is not available");
        }

        OrderItem orderItem = new OrderItem();
        orderItem.setOrder(order);
        orderItem.setMenuItem(menuItem);
        orderItem.setQuantity(quantity);

        if (notes != null && !notes.trim().isEmpty()) {
            orderItem.setNotes(notes.trim());
        }

        // Initialize orderItems list if null
        if (order.getOrderItems() == null) {
            order.setOrderItems(new ArrayList<>());
        }
        order.getOrderItems().add(orderItem);

        // Set total if null
        if (order.getTotalAmount() == null) {
            order.setTotalAmount(BigDecimal.ZERO);
        }

        BigDecimal itemTotal = menuItem.getPrice().multiply(BigDecimal.valueOf(quantity));
        order.setTotalAmount(order.getTotalAmount().add(itemTotal));

        orderItemRepository.save(orderItem);
        orderRepository.save(order);
    }



    public List<Order> getActiveOrders() {
        return orderRepository.findActiveOrders();
    }

    public List<Order> getOrdersByCustomer(User customer) {
        return orderRepository.findByCustomerOrderByOrderTimeDesc(customer);
    }

    public Optional<Order> getOrderById(Long orderId) {
        return orderRepository.findById(orderId);
    }

    public Order updateOrderStatus(Long orderId, Order.OrderStatus status) {
        Optional<Order> orderOpt = orderRepository.findById(orderId);
        if (!orderOpt.isPresent()) {
            throw new RuntimeException("Order not found");
        }

        Order order = orderOpt.get();
        order.setStatus(status);
        
        if (status == Order.OrderStatus.DELIVERED) {
            order.setDeliveryTime(LocalDateTime.now());
        }
        
        return orderRepository.save(order);
    }

    public OrderItem updateOrderItemStatus(Long orderItemId, OrderItem.ItemStatus status) {
        Optional<OrderItem> orderItemOpt = orderItemRepository.findById(orderItemId);
        if (!orderItemOpt.isPresent()) {
            throw new RuntimeException("Order item not found");
        }

        OrderItem orderItem = orderItemOpt.get();
        orderItem.setStatus(status);
        
        return orderItemRepository.save(orderItem);
    }

    public Order finalizeOrder(Long orderId) {
        Optional<Order> orderOpt = orderRepository.findById(orderId);
        if (!orderOpt.isPresent()) {
            throw new RuntimeException("Order not found");
        }

        Order order = orderOpt.get();
        
        // Calculate overtime charges if applicable
        if (order.getTable() != null) {
            BigDecimal overtimeCharges = tableService.calculateOvertimeCharges(order.getTable());
            order.setOvertimeCharges(overtimeCharges);
        }
        
        order.calculateTotalAmount();
        order.setStatus(Order.OrderStatus.DELIVERED);
        order.setDeliveryTime(LocalDateTime.now());
        
        return orderRepository.save(order);
    }

    public void cancelOrder(Long orderId) {
        Optional<Order> orderOpt = orderRepository.findById(orderId);
        if (orderOpt.isPresent()) {
            Order order = orderOpt.get();
            order.setStatus(Order.OrderStatus.CANCELLED);
            orderRepository.save(order);
        }
    }

    public List<Order> getOrdersByStatus(Order.OrderStatus status) {
        return orderRepository.findByStatus(status);
    }

    public List<Order> getOrdersByDateRange(LocalDateTime startDate, LocalDateTime endDate) {
        return orderRepository.findByOrderTimeBetween(startDate, endDate);
    }
}
