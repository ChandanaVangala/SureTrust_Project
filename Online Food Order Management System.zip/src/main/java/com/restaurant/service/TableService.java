package com.restaurant.service;

import com.restaurant.model.RestaurantTable;
import com.restaurant.model.User;
import com.restaurant.repository.RestaurantTableRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

@Service
public class TableService {

    @Autowired
    private RestaurantTableRepository tableRepository;

    private static final BigDecimal OVERTIME_RATE_PER_HOUR = new BigDecimal("50.00");

    public List<RestaurantTable> getAllTables() {
        return tableRepository.findAll();
    }

    public List<RestaurantTable> getAvailableTables() {
        return tableRepository.findAvailableTables(LocalDateTime.now());
    }

    public Optional<RestaurantTable> getTableById(Long id) {
        return tableRepository.findById(id);
    }

    public Optional<RestaurantTable> getTableByNumber(Integer tableNumber) {
        return tableRepository.findByTableNumber(tableNumber);
    }

    public RestaurantTable bookTable(Long tableId, User customer, LocalDateTime startTime, int durationHours) {
        Optional<RestaurantTable> tableOpt = tableRepository.findById(tableId);
        if (!tableOpt.isPresent()) {
            throw new RuntimeException("Table not found");
        }

        RestaurantTable table = tableOpt.get();
        LocalDateTime endTime = startTime.plusHours(durationHours);

        // Check if table is available for the requested time slot
        List<RestaurantTable> conflictingTables = tableRepository.findTablesBookedBetween(startTime, endTime);
        boolean hasConflict = conflictingTables.stream()
                .anyMatch(t -> t.getId().equals(tableId));

        if (hasConflict) {
            throw new RuntimeException("Table is not available for the requested time slot");
        }

        table.setStatus(RestaurantTable.TableStatus.BOOKED);
        table.setBookedBy(customer);
        table.setBookingStartTime(startTime);
        table.setBookingEndTime(endTime);

        return tableRepository.save(table);
    }

    public RestaurantTable occupyTable(Long tableId) {
        Optional<RestaurantTable> tableOpt = tableRepository.findById(tableId);
        if (!tableOpt.isPresent()) {
            throw new RuntimeException("Table not found");
        }

        RestaurantTable table = tableOpt.get();
        table.setStatus(RestaurantTable.TableStatus.OCCUPIED);
        table.setActualStartTime(LocalDateTime.now());

        return tableRepository.save(table);
    }

    public RestaurantTable vacateTable(Long tableId) {
        Optional<RestaurantTable> tableOpt = tableRepository.findById(tableId);
        if (!tableOpt.isPresent()) {
            throw new RuntimeException("Table not found");
        }

        RestaurantTable table = tableOpt.get();
        table.setActualEndTime(LocalDateTime.now());
        table.setStatus(RestaurantTable.TableStatus.AVAILABLE);

        return tableRepository.save(table);
    }

    public BigDecimal calculateOvertimeCharges(RestaurantTable table) {
        if (table.getActualEndTime() == null || table.getBookingEndTime() == null) {
            return BigDecimal.ZERO;
        }

        if (table.getActualEndTime().isAfter(table.getBookingEndTime())) {
            long overtimeMinutes = ChronoUnit.MINUTES.between(table.getBookingEndTime(), table.getActualEndTime());
            double overtimeHours = overtimeMinutes / 60.0;
            return OVERTIME_RATE_PER_HOUR.multiply(BigDecimal.valueOf(overtimeHours));
        }

        return BigDecimal.ZERO;
    }

    public RestaurantTable createTable(Integer tableNumber, Integer capacity) {
        if (tableRepository.findByTableNumber(tableNumber).isPresent()) {
            throw new RuntimeException("Table number already exists");
        }

        RestaurantTable table = new RestaurantTable(tableNumber, capacity);
        return tableRepository.save(table);
    }

    public void deleteTable(Long tableId) {
        tableRepository.deleteById(tableId);
    }

    public List<RestaurantTable> getTablesByStatus(RestaurantTable.TableStatus status) {
        return tableRepository.findByStatus(status);
    }
    
    public List<RestaurantTable> getTablesByCustomer(User customer) {
        return tableRepository.findByBookedBy(customer);
    }
}
