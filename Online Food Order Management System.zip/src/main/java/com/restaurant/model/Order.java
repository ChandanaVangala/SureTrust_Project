package com.restaurant.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "orders")
public class Order {
	

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "customer_id", nullable = false)
    private User customer;

    @ManyToOne
    @JoinColumn(name = "table_id")
    private RestaurantTable table;

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<OrderItem> orderItems = new ArrayList<>();

    @Enumerated(EnumType.STRING)
    private OrderStatus status = OrderStatus.PENDING;

    private LocalDateTime orderTime = LocalDateTime.now();
    private LocalDateTime deliveryTime;

    private BigDecimal totalAmount = BigDecimal.ZERO;
    private BigDecimal overtimeCharges = BigDecimal.ZERO;

    private String specialInstructions;

    public enum OrderStatus {
        PENDING, PREPARING, READY, DELIVERED, CANCELLED
    }
    
    // Constructors
    public Order() {
        this.orderTime = LocalDateTime.now();
        this.status = OrderStatus.PENDING;
        this.totalAmount = BigDecimal.ZERO;
        this.overtimeCharges = BigDecimal.ZERO;
        this.orderItems = new ArrayList<>();
    }

    public Order(User customer, RestaurantTable table) {
        this(); // Call default constructor to initialize all fields
        this.customer = customer;
        this.table = table;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getCustomer() {
        return customer;
    }

    public void setCustomer(User customer) {
        this.customer = customer;
    }

    public RestaurantTable getTable() {
        return table;
    }

    public void setTable(RestaurantTable table) {
        this.table = table;
    }

    public List<OrderItem> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(List<OrderItem> orderItems) {
        this.orderItems = orderItems;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public LocalDateTime getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(LocalDateTime orderTime) {
        this.orderTime = orderTime;
    }

    public LocalDateTime getDeliveryTime() {
        return deliveryTime;
    }

    public void setDeliveryTime(LocalDateTime deliveryTime) {
        this.deliveryTime = deliveryTime;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public BigDecimal getOvertimeCharges() {
        return overtimeCharges;
    }

    public void setOvertimeCharges(BigDecimal overtimeCharges) {
        this.overtimeCharges = overtimeCharges;
    }

    public String getSpecialInstructions() {
        return specialInstructions;
    }

    public void setSpecialInstructions(String specialInstructions) {
        this.specialInstructions = specialInstructions;
    }

    public void addOrderItem(OrderItem orderItem) {
        orderItems.add(orderItem);
        orderItem.setOrder(this);
        calculateTotalAmount();
    }

    public void calculateTotalAmount() {
        if (orderItems == null || orderItems.isEmpty()) {
            this.totalAmount = (overtimeCharges != null) ? overtimeCharges : BigDecimal.ZERO;
            return;
        }
        
        BigDecimal itemsTotal = orderItems.stream()
                .filter(item -> item != null && item.getMenuItem() != null && item.getMenuItem().getPrice() != null && item.getQuantity() != null)
                .map(item -> item.getMenuItem().getPrice().multiply(BigDecimal.valueOf(item.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        BigDecimal charges = (overtimeCharges != null) ? overtimeCharges : BigDecimal.ZERO;
        this.totalAmount = itemsTotal.add(charges);
    }
}
