package com.restaurant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantManagementApplication {

    public static void main(String[] args) {
    	System.out.println("Hello Application");
    	System.out.println("Hello Application");
        SpringApplication.run(RestaurantManagementApplication.class, args);
    }
}
