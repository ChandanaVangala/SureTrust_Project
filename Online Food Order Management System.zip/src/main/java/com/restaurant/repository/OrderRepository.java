package com.restaurant.repository;

import com.restaurant.model.Order;
import com.restaurant.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByCustomer(User customer);
    List<Order> findByStatus(Order.OrderStatus status);
    List<Order> findByOrderTimeBetween(LocalDateTime startTime, LocalDateTime endTime);
    
    @Query("SELECT o FROM Order o WHERE o.status IN ('PENDING', 'PREPARING', 'READY') ORDER BY o.orderTime ASC")
    List<Order> findActiveOrders();
    
    @Query("SELECT o FROM Order o WHERE o.customer = :customer ORDER BY o.orderTime DESC")
    List<Order> findByCustomerOrderByOrderTimeDesc(User customer);
    
    @Query("SELECT o FROM Order o WHERE o.table.id = :tableId AND o.status != 'DELIVERED' AND o.status != 'CANCELLED'")
    List<Order> findActiveOrdersByTableId(Long tableId);
}
