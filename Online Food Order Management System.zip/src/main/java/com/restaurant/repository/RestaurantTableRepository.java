package com.restaurant.repository;

import com.restaurant.model.RestaurantTable;
import com.restaurant.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface RestaurantTableRepository extends JpaRepository<RestaurantTable, Long> {
    Optional<RestaurantTable> findByTableNumber(Integer tableNumber);
    List<RestaurantTable> findByStatus(RestaurantTable.TableStatus status);
    
    @Query("SELECT t FROM RestaurantTable t WHERE t.status = 'AVAILABLE' OR " +
           "(t.status = 'BOOKED' AND t.bookingEndTime < :currentTime)")
    List<RestaurantTable> findAvailableTables(@Param("currentTime") LocalDateTime currentTime);
    
    @Query("SELECT t FROM RestaurantTable t WHERE t.status = 'BOOKED' AND " +
           "t.bookingStartTime <= :endTime AND t.bookingEndTime >= :startTime")
    List<RestaurantTable> findTablesBookedBetween(@Param("startTime") LocalDateTime startTime, 
                                                   @Param("endTime") LocalDateTime endTime);
    
    List<RestaurantTable> findByBookedBy(User bookedBy);
}
