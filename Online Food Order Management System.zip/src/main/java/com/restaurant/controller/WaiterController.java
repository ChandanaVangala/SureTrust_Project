package com.restaurant.controller;

import com.restaurant.model.*;
import com.restaurant.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/waiter")
public class WaiterController {

    @Autowired
    private UserService userService;

    @Autowired
    private OrderService orderService;

    @Autowired
    private TableService tableService;

    @Autowired
    private MenuService menuService;

    private User getCurrentUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return userService.findByUsername(auth.getName()).orElse(null);
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        User waiter = getCurrentUser();
        model.addAttribute("waiter", waiter);
        
        List<Order> activeOrders = orderService.getActiveOrders();
        model.addAttribute("activeOrders", activeOrders);
        
        List<RestaurantTable> bookedTables = tableService.getTablesByStatus(RestaurantTable.TableStatus.BOOKED);
        List<RestaurantTable> occupiedTables = tableService.getTablesByStatus(RestaurantTable.TableStatus.OCCUPIED);
        model.addAttribute("bookedTables", bookedTables);
        model.addAttribute("occupiedTables", occupiedTables);
        
        return "waiter/dashboard";
    }

    @GetMapping("/orders")
    public String viewOrders(Model model, @RequestParam(required = false) String status) {
        List<Order> orders;
        
        if (status != null && !status.isEmpty()) {
            try {
                Order.OrderStatus orderStatus = Order.OrderStatus.valueOf(status.toUpperCase());
                orders = orderService.getOrdersByStatus(orderStatus);
            } catch (IllegalArgumentException e) {
                orders = orderService.getActiveOrders();
            }
        } else {
            orders = orderService.getActiveOrders();
        }
        
        model.addAttribute("orders", orders);
        model.addAttribute("orderStatuses", Order.OrderStatus.values());
        model.addAttribute("selectedStatus", status);
        
        return "waiter/orders";
    }
    
//    @GetMapping("/waiter/orders")
//    public String viewAllOrders(Model model) {
//        List<Order> allOrders = orderRepository.findAll();
//        model.addAttribute("orders", allOrders);
//        return "waiter/orders";
//    }


    @GetMapping("/order/{orderId}")
    public String viewOrderDetails(@PathVariable Long orderId, Model model) {
        Optional<Order> order = orderService.getOrderById(orderId);
        if (!order.isPresent()) {
            return "redirect:/waiter/orders";
        }
        
        model.addAttribute("order", order.get());
        model.addAttribute("orderStatuses", Order.OrderStatus.values());
        model.addAttribute("itemStatuses", OrderItem.ItemStatus.values());
        
        return "waiter/order-details";
    }

    @PostMapping("/order/{orderId}/status")
    public String updateOrderStatus(@PathVariable Long orderId,
                                   @RequestParam String status,
                                   RedirectAttributes redirectAttributes) {
        try {
            Order.OrderStatus orderStatus = Order.OrderStatus.valueOf(status.toUpperCase());
            orderService.updateOrderStatus(orderId, orderStatus);
            redirectAttributes.addFlashAttribute("success", "Order status updated successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to update order status: " + e.getMessage());
        }
        
        return "redirect:/waiter/order/" + orderId;
    }

    @PostMapping("/order-item/{itemId}/status")
    public String updateOrderItemStatus(@PathVariable Long itemId,
                                       @RequestParam String status,
                                       @RequestParam Long orderId,
                                       RedirectAttributes redirectAttributes) {
        try {
            OrderItem.ItemStatus itemStatus = OrderItem.ItemStatus.valueOf(status.toUpperCase());
            orderService.updateOrderItemStatus(itemId, itemStatus);
            redirectAttributes.addFlashAttribute("success", "Item status updated successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to update item status: " + e.getMessage());
        }
        
        return "redirect:/waiter/order/" + orderId;
    }

    @GetMapping("/tables")
    public String viewTables(Model model) {
        List<RestaurantTable> tables = tableService.getAllTables();
        model.addAttribute("tables", tables);
        model.addAttribute("tableStatuses", RestaurantTable.TableStatus.values());
        
        return "waiter/tables";
    }

    @PostMapping("/table/{tableId}/occupy")
    public String occupyTable(@PathVariable Long tableId, RedirectAttributes redirectAttributes) {
        try {
            tableService.occupyTable(tableId);
            redirectAttributes.addFlashAttribute("success", "Table marked as occupied!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to occupy table: " + e.getMessage());
        }
        
        return "redirect:/waiter/tables";
    }

    @PostMapping("/table/{tableId}/vacate")
    public String vacateTable(@PathVariable Long tableId, RedirectAttributes redirectAttributes) {
        try {
            tableService.vacateTable(tableId);
            redirectAttributes.addFlashAttribute("success", "Table vacated successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to vacate table: " + e.getMessage());
        }
        
        return "redirect:/waiter/tables";
    }

    @GetMapping("/billing/{orderId}")
    public String generateBill(@PathVariable Long orderId, Model model) {
        Optional<Order> order = orderService.getOrderById(orderId);
        if (!order.isPresent()) {
            return "redirect:/waiter/orders";
        }
        
        Order finalOrder = orderService.finalizeOrder(orderId);
        model.addAttribute("order", finalOrder);
        
        return "waiter/bill";
    }

    @GetMapping("/menu")
    public String viewMenu(Model model) {
        List<MenuItem> menuItems = menuService.getAllMenuItems();
        model.addAttribute("menuItems", menuItems);
        model.addAttribute("categories", MenuItem.Category.values());
        
        return "waiter/menu";
    }

    @PostMapping("/menu/{itemId}/toggle-availability")
    public String toggleMenuItemAvailability(@PathVariable Long itemId, RedirectAttributes redirectAttributes) {
        try {
            menuService.toggleAvailability(itemId);
            redirectAttributes.addFlashAttribute("success", "Menu item availability updated!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to update availability: " + e.getMessage());
        }
        
        return "redirect:/waiter/menu";
    }
}
