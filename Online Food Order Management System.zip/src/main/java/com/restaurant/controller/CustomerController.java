package com.restaurant.controller;

import com.restaurant.model.*;
import com.restaurant.repository.MenuItemRepository;
import com.restaurant.repository.OrderItemRepository;
import com.restaurant.repository.OrderRepository;
import com.restaurant.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/customer")
public class CustomerController {

    @Autowired
    private UserService userService;

    @Autowired
    private MenuService menuService;

    @Autowired
    private OrderService orderService;

    @Autowired
    private TableService tableService;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private MenuItemRepository menuItemRepository;

    @Autowired
    private OrderItemRepository orderItemRepository;

    private User getCurrentUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return userService.findByUsername(auth.getName()).orElse(null);
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        User customer = getCurrentUser();
        model.addAttribute("customer", customer);

        List<Order> recentOrders = orderService.getOrdersByCustomer(customer);
        model.addAttribute("recentOrders", recentOrders.stream().limit(5).toList());

        List<RestaurantTable> availableTables = tableService.getAvailableTables();
        model.addAttribute("availableTables", availableTables);

        List<MenuItem> menuItems = menuService.getAvailableMenuItems();
        model.addAttribute("menuItems", menuItems);

        return "customer/dashboard";
    }

    
//    @PostMapping("/order/{orderId}/add-item")
//    public String addSingleItem(@PathVariable Long orderId,
//                                @RequestParam Long menuItemId,
//                                @RequestParam Integer quantity,
//                                @RequestParam(required = false) String notes,
//                                RedirectAttributes redirectAttributes) {
//        Optional<Order> optionalOrder = orderRepository.findById(orderId);
//        Optional<MenuItem> optionalItem = menuItemRepository.findById(menuItemId);
//
//        if (optionalOrder.isEmpty() || optionalItem.isEmpty()) {
//            redirectAttributes.addFlashAttribute("error", "Invalid order or item.");
//            return "redirect:/customer/order/" + orderId + "/add-items";
//        }
//
//        MenuItem item = optionalItem.get();
//        Order order = optionalOrder.get();
//
//        OrderItem orderItem = new OrderItem();
//        orderItem.setOrder(order);
//        orderItem.setMenuItem(item);
//        orderItem.setQuantity(quantity);
//        orderItem.setPrice(item.getPrice().multiply(BigDecimal.valueOf(quantity)));
//        orderItem.setNotes(notes);
//        orderItemRepository.save(orderItem);
//
//        redirectAttributes.addFlashAttribute("success", "Item added to order!");
//        return "redirect:/customer/order/" + orderId + "/add-items";
//    }
    
   
    @PostMapping("/order/{orderId}/add-item")
    public String addSingleItem(@PathVariable Long orderId,
                                @RequestParam Long menuItemId,
                                @RequestParam Integer quantity,
                                @RequestParam(required = false) String notes,
                                RedirectAttributes redirectAttributes) {
        Optional<Order> optionalOrder = orderRepository.findById(orderId);
        Optional<MenuItem> optionalItem = menuItemRepository.findById(menuItemId);

        if (optionalOrder.isEmpty() || optionalItem.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Invalid order or item.");
            return "redirect:/customer/order/" + orderId + "/add-items";
        }

        MenuItem item = optionalItem.get();
        Order order = optionalOrder.get();

        OrderItem orderItem = new OrderItem();
        orderItem.setOrder(order);
        orderItem.setMenuItem(item);
        orderItem.setQuantity(quantity);
        orderItem.setPrice(item.getPrice().multiply(BigDecimal.valueOf(quantity)));
        orderItem.setNotes(notes);
        orderItemRepository.save(orderItem);

        // 🔄 Update total
        order = orderRepository.findById(orderId).get(); // reload to ensure latest items
        BigDecimal newTotal = order.getOrderItems().stream()
            .map(OrderItem::getPrice)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        order.setTotalAmount(newTotal);
        orderRepository.save(order);

        redirectAttributes.addFlashAttribute("success", "Item added to order!");
        return "redirect:/customer/order/" + orderId + "/add-items";
    }


    
    @GetMapping("/menu")
    public String viewMenu(Model model, @RequestParam(required = false) String category) {
        List<MenuItem> menuItems;

        if (category != null && !category.isEmpty()) {
            try {
                MenuItem.Category cat = MenuItem.Category.valueOf(category.toUpperCase());
                menuItems = menuService.getMenuItemsByCategory(cat);
            } catch (IllegalArgumentException e) {
                menuItems = menuService.getAvailableMenuItems();
            }
        } else {
            menuItems = menuService.getAvailableMenuItems();
        }

        model.addAttribute("menuItems", menuItems);
        model.addAttribute("categories", MenuItem.Category.values());
        model.addAttribute("selectedCategory", category);

        return "customer/menu";
    }

    @GetMapping("/order")
    public String createOrder(Model model) {
        List<RestaurantTable> availableTables = tableService.getAvailableTables();
        model.addAttribute("availableTables", availableTables);
        return "customer/create-order";
    }

    @PostMapping("/order/create")
    public String createOrder(@RequestParam Long tableId,
                             @RequestParam(required = false) String specialInstructions,
                             RedirectAttributes redirectAttributes) {
        try {
            User customer = getCurrentUser();
            List<RestaurantTable> customerTables = tableService.getTablesByCustomer(customer);
            boolean hasBookedTable = customerTables.stream().anyMatch(table -> table.getId().equals(tableId));

            if (!hasBookedTable) {
                redirectAttributes.addFlashAttribute("error", "You must book a table first before placing an order!");
                return "redirect:/customer/place-order";
            }

            Order order = orderService.createOrder(customer, tableId, specialInstructions);
            redirectAttributes.addFlashAttribute("success", "Order created successfully!");
            return "redirect:/customer/order/" + order.getId() + "/add-items";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to create order: " + e.getMessage());
            return "redirect:/customer/place-order";
        }
    }

    @GetMapping("/order/{orderId}/add-items")
    public String showAddItemsPage(@PathVariable Long orderId, Model model, RedirectAttributes redirectAttributes) {
        Optional<Order> optionalOrder = orderRepository.findById(orderId);
        if (optionalOrder.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Order not found.");
            return "redirect:/customer/dashboard";
        }

        List<MenuItem> menuItems = menuItemRepository.findAll();
        model.addAttribute("order", optionalOrder.get());
        model.addAttribute("menuItems", menuItems);

        return "customer/add-items";
    }

//    @PostMapping("/order/{orderId}/add-items")
//    public String addItemsToOrder(@PathVariable Long orderId,
//                                   @RequestParam(name = "menuItemIds", required = false) List<Long> menuItemIds,
//                                   @RequestParam(name = "quantities", required = false) List<Integer> quantities,
//                                   RedirectAttributes redirectAttributes) {
//        Optional<Order> optionalOrder = orderRepository.findById(orderId);
//        if (optionalOrder.isEmpty()) {
//            redirectAttributes.addFlashAttribute("error", "Order not found.");
//            return "redirect:/customer/dashboard";
//        }
//
//        Order order = optionalOrder.get();
//        for (int i = 0; i < menuItemIds.size(); i++) {
//            Long menuItemId = menuItemIds.get(i);
//            int quantity = quantities.get(i);
//            if (quantity > 0) {
//                Optional<MenuItem> optionalMenuItem = menuItemRepository.findById(menuItemId);
//                optionalMenuItem.ifPresent(menuItem -> {
//                    OrderItem item = new OrderItem();
//                    item.setOrder(order);
//                    item.setMenuItem(menuItem);
//                    item.setQuantity(quantity);
//                    orderItemRepository.save(item);
//                });
//            }
//        }
//
//        redirectAttributes.addFlashAttribute("success", "Items added to order.");
//        return "redirect:/customer/orders";
//    }

//    @PostMapping("/order/{orderId}/add-items")
//    public String addItemsToOrder(@PathVariable Long orderId,
//                                  @RequestParam("menuItemIds") List<Long> menuItemIds,
//                                  @RequestParam("quantities") List<Integer> quantities,
//                                  RedirectAttributes redirectAttributes) {
//        Optional<Order> optionalOrder = orderRepository.findById(orderId);
//        if (optionalOrder.isEmpty()) {
//            redirectAttributes.addFlashAttribute("error", "Order not found.");
//            return "redirect:/customer/dashboard";
//        }
//
//        Order order = optionalOrder.get();
//
//        for (int i = 0; i < menuItemIds.size(); i++) {
//            Long menuItemId = menuItemIds.get(i);
//            int quantity = quantities.get(i);
//
//            Optional<MenuItem> optionalMenuItem = menuItemRepository.findById(menuItemId);
//            if (optionalMenuItem.isPresent() && quantity > 0) {
//                MenuItem menuItem = optionalMenuItem.get();
//
//                OrderItem orderItem = new OrderItem();
//                orderItem.setOrder(order);
//                orderItem.setMenuItem(menuItem);
//                orderItem.setQuantity(quantity);
//                orderItem.setPrice(menuItem.getPrice().multiply(BigDecimal.valueOf(quantity)));
//
//                orderItemRepository.save(orderItem);
//            }
//        }
//
//        redirectAttributes.addFlashAttribute("success", "Items added to order.");
//        return "redirect:/customer/dashboard";
//    }
    
    @PostMapping("/order/{orderId}/add-items")
    public String addItemsToOrder(@PathVariable Long orderId,
                                  @RequestParam("menuItemIds") List<Long> menuItemIds,
                                  @RequestParam("quantities") List<Integer> quantities,
                                  RedirectAttributes redirectAttributes) {
        Optional<Order> optionalOrder = orderRepository.findById(orderId);
        if (optionalOrder.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Order not found.");
            return "redirect:/customer/dashboard";
        }

        Order order = optionalOrder.get();

        for (int i = 0; i < menuItemIds.size(); i++) {
            Long menuItemId = menuItemIds.get(i);
            int quantity = quantities.get(i);

            Optional<MenuItem> optionalMenuItem = menuItemRepository.findById(menuItemId);
            if (optionalMenuItem.isPresent() && quantity > 0) {
                MenuItem menuItem = optionalMenuItem.get();

                OrderItem orderItem = new OrderItem();
                orderItem.setOrder(order);
                orderItem.setMenuItem(menuItem);
                orderItem.setQuantity(quantity);
                orderItem.setPrice(menuItem.getPrice().multiply(BigDecimal.valueOf(quantity)));

                orderItemRepository.save(orderItem);
            }
        }

        // 🔄 Re-fetch and update total
        order = orderRepository.findById(orderId).get(); // reload to ensure all new items included
        BigDecimal newTotal = order.getOrderItems().stream()
            .map(OrderItem::getPrice)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        order.setTotalAmount(newTotal);
        orderRepository.save(order);

        redirectAttributes.addFlashAttribute("success", "Items added to order.");
        return "redirect:/customer/dashboard";
    }


    
    @GetMapping("/orders")
    public String viewOrders(Model model) {
        User customer = getCurrentUser();
        List<Order> orders = orderService.getOrdersByCustomer(customer);
        model.addAttribute("orders", orders);
        return "customer/orders";
    }

    @GetMapping("/order/{orderId}")
    public String viewOrder(@PathVariable Long orderId, Model model) {
        Optional<Order> order = orderService.getOrderById(orderId);
        if (!order.isPresent()) {
            return "redirect:/customer/orders";
        }

        model.addAttribute("order", order.get());
        return "customer/order-details";
    }

    @GetMapping("/tables")
    public String viewTables(Model model) {
        List<RestaurantTable> availableTables = tableService.getAvailableTables();
        model.addAttribute("tables", availableTables);
        return "customer/tables";
    }

    @GetMapping("/place-order")
    public String placeOrder(Model model) {
        User customer = getCurrentUser();
        List<RestaurantTable> customerBookedTables = tableService.getTablesByCustomer(customer);

        if (customerBookedTables.isEmpty()) {
            List<RestaurantTable> availableTables = tableService.getAvailableTables();
            model.addAttribute("availableTables", availableTables);
            model.addAttribute("needsTableBooking", true);
            return "customer/place-order";
        } else {
            model.addAttribute("bookedTables", customerBookedTables);
            model.addAttribute("menuItems", menuService.getAvailableMenuItems());
            model.addAttribute("categories", MenuItem.Category.values());
            model.addAttribute("needsTableBooking", false);
            return "customer/place-order";
        }
    }

    @PostMapping("/table/{tableId}/book")
    public String bookTable(@PathVariable Long tableId,
                           @RequestParam String bookingDate,
                           @RequestParam String bookingTime,
                           @RequestParam(defaultValue = "1") int duration,
                           RedirectAttributes redirectAttributes) {
        try {
            User customer = getCurrentUser();
            LocalDateTime startTime = LocalDateTime.parse(bookingDate + "T" + bookingTime);
            tableService.bookTable(tableId, customer, startTime, duration);
            redirectAttributes.addFlashAttribute("success", "Table booked successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to book table: " + e.getMessage());
        }

        return "redirect:/customer/tables";
    }
}