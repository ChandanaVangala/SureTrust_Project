package com.restaurant.controller;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletRequest;

@Controller
public class CustomErrorController implements ErrorController {

    @RequestMapping("/error")
    public String handleError(HttpServletRequest request, Model model) {
        Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
        String errorMessage = "An unexpected error occurred";
        String errorTitle = "Error";
        
        if (status != null) {
            Integer statusCode = Integer.valueOf(status.toString());
            
            switch (statusCode) {
                case 404:
                    errorTitle = "Page Not Found";
                    errorMessage = "The page you are looking for could not be found.";
                    break;
                case 500:
                    errorTitle = "Internal Server Error";
                    errorMessage = "Something went wrong on our end. Please try again later.";
                    break;
                case 403:
                    errorTitle = "Access Denied";
                    errorMessage = "You don't have permission to access this resource.";
                    break;
                default:
                    errorTitle = "Error " + statusCode;
                    errorMessage = "An error occurred while processing your request.";
                    break;
            }
            
            model.addAttribute("statusCode", statusCode);
        }
        
        model.addAttribute("errorTitle", errorTitle);
        model.addAttribute("errorMessage", errorMessage);
        
        return "error";
    }
}
