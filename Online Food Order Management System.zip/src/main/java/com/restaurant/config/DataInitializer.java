package com.restaurant.config;

import com.restaurant.model.MenuItem;
import com.restaurant.model.RestaurantTable;
import com.restaurant.model.User;
import com.restaurant.service.MenuService;
import com.restaurant.service.TableService;
import com.restaurant.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserService userService;

    @Autowired
    private MenuService menuService;

    @Autowired
    private TableService tableService;

    @Override
    public void run(String... args) throws Exception {
        initializeUsers();
        initializeMenuItems();
        initializeTables();
    }

    private void initializeUsers() {
        // Create default waiter if not exists
        if (!userService.findByUsername("waiter").isPresent()) {
            User waiter = new User("waiter", "password123", "waiter@restaurant.com", "John Waiter", User.Role.WAITER);
            userService.registerUser(waiter);
            System.out.println("Default waiter created: username=waiter, password=password123");
        }

        // Create default customer if not exists
        if (!userService.findByUsername("customer").isPresent()) {
            User customer = new User("customer", "password123", "customer@restaurant.com", "Jane Customer", User.Role.CUSTOMER);
            userService.registerUser(customer);
            System.out.println("Default customer created: username=customer, password=password123");
        }
    }

    private void initializeMenuItems() {
        if (menuService.getAllMenuItems().isEmpty()) {
            // Starters
            menuService.saveMenuItem(new MenuItem("Caesar Salad", "Fresh romaine lettuce with Caesar dressing and croutons", new BigDecimal("12.99"), MenuItem.Category.STARTERS));
            menuService.saveMenuItem(new MenuItem("Chicken Wings", "Spicy buffalo wings served with blue cheese dip", new BigDecimal("14.99"), MenuItem.Category.STARTERS));
            menuService.saveMenuItem(new MenuItem("Mozzarella Sticks", "Golden fried mozzarella with marinara sauce", new BigDecimal("10.99"), MenuItem.Category.STARTERS));

            // Main Course
            menuService.saveMenuItem(new MenuItem("Grilled Salmon", "Fresh Atlantic salmon with lemon herb butter", new BigDecimal("24.99"), MenuItem.Category.MAIN_COURSE));
            menuService.saveMenuItem(new MenuItem("Ribeye Steak", "12oz prime ribeye steak with garlic mashed potatoes", new BigDecimal("32.99"), MenuItem.Category.MAIN_COURSE));
            menuService.saveMenuItem(new MenuItem("Chicken Parmesan", "Breaded chicken breast with marinara and mozzarella", new BigDecimal("19.99"), MenuItem.Category.MAIN_COURSE));
            menuService.saveMenuItem(new MenuItem("Vegetarian Pasta", "Penne pasta with seasonal vegetables in olive oil", new BigDecimal("16.99"), MenuItem.Category.MAIN_COURSE));

            // Desserts
            menuService.saveMenuItem(new MenuItem("Chocolate Cake", "Rich chocolate layer cake with chocolate ganache", new BigDecimal("8.99"), MenuItem.Category.DESSERTS));
            menuService.saveMenuItem(new MenuItem("Tiramisu", "Classic Italian dessert with coffee and mascarpone", new BigDecimal("9.99"), MenuItem.Category.DESSERTS));
            menuService.saveMenuItem(new MenuItem("Ice Cream Sundae", "Vanilla ice cream with chocolate sauce and nuts", new BigDecimal("6.99"), MenuItem.Category.DESSERTS));

            // Beverages
            menuService.saveMenuItem(new MenuItem("Coffee", "Freshly brewed coffee", new BigDecimal("3.99"), MenuItem.Category.BEVERAGES));
            menuService.saveMenuItem(new MenuItem("Fresh Orange Juice", "Freshly squeezed orange juice", new BigDecimal("4.99"), MenuItem.Category.BEVERAGES));
            menuService.saveMenuItem(new MenuItem("Soft Drinks", "Coca-Cola, Pepsi, Sprite, etc.", new BigDecimal("2.99"), MenuItem.Category.BEVERAGES));

            System.out.println("Sample menu items created");
        }
    }

    private void initializeTables() {
        if (tableService.getAllTables().isEmpty()) {
            // Create 15 tables with different capacities
            for (int i = 1; i <= 15; i++) {
                int capacity = (i <= 5) ? 2 : (i <= 10) ? 4 : (i <= 13) ? 6 : 8;
                tableService.createTable(i, capacity);
            }
            System.out.println("15 restaurant tables created");
        }
    }
}
