package com.restaurant.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class DatabaseInitializer implements CommandLineRunner {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void run(String... args) throws Exception {
        System.out.println("Creating database tables...");
        
        try {
            // Create Users table
            jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS users (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                "username VARCHAR(50) UNIQUE NOT NULL, " +
                "email VARCHAR(100) UNIQUE NOT NULL, " +
                "password VARCHAR(255) NOT NULL, " +
                "full_name VARCHAR(100) NOT NULL, " +
                "role VARCHAR(20) NOT NULL, " +
                "enabled BOOLEAN DEFAULT TRUE" +
                ")");
            
            // Create Restaurant Tables
            jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS restaurant_tables (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                "table_number INTEGER UNIQUE NOT NULL, " +
                "capacity INTEGER NOT NULL, " +
                "status VARCHAR(20) DEFAULT 'AVAILABLE', " +
                "booked_by_user_id BIGINT, " +
                "booking_start_time TIMESTAMP, " +
                "booking_end_time TIMESTAMP, " +
                "actual_start_time TIMESTAMP, " +
                "actual_end_time TIMESTAMP" +
                ")");
            
            // Create Menu Items table
            jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS menu_items (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                "name VARCHAR(100) NOT NULL, " +
                "description TEXT, " +
                "price DECIMAL(10,2) NOT NULL, " +
                "category VARCHAR(20) NOT NULL, " +
                "available BOOLEAN DEFAULT TRUE" +
                ")");
            
            // Create Orders table
            jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS orders (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                "customer_id BIGINT NOT NULL, " +
                "table_id BIGINT, " +
                "status VARCHAR(20) DEFAULT 'PENDING', " +
                "order_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                "delivery_time TIMESTAMP, " +
                "total_amount DECIMAL(10,2) DEFAULT 0.00, " +
                "overtime_charges DECIMAL(10,2) DEFAULT 0.00, " +
                "special_instructions TEXT" +
                ")");
            
            // Create Order Items table
            jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS order_items (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                "order_id BIGINT NOT NULL, " +
                "menu_item_id BIGINT NOT NULL, " +
                "quantity INTEGER NOT NULL, " +
                "special_instructions TEXT" +
                ")");
            
            System.out.println("Database tables created successfully!");
            
            // Initialize sample data
            initializeSampleData();
            
        } catch (Exception e) {
            System.err.println("Error creating database tables: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
//    private void initializeSampleData() {
//        try {
//            // Check if tables already have data
//            Integer userCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM restaurant_tables", Integer.class);
//            if (userCount > 0) {
//                System.out.println("Sample data already exists, skipping initialization.");
//                return;
//            }
//            
//            // Create 15 restaurant tables
//            for (int i = 1; i <= 15; i++) {
//                jdbcTemplate.update("INSERT INTO restaurant_tables (table_number, capacity, status) VALUES (?, ?, 'AVAILABLE')", 
//                    i, (i % 3) + 2); // Capacity between 2-4
//            }
//            
//            // Create sample menu items
//            jdbcTemplate.update("INSERT INTO menu_items (name, description, price, category, available) VALUES " +
//                "('Caesar Salad', 'Fresh romaine lettuce with caesar dressing', 8.99, 'STARTER', true), " +
//                "('Grilled Chicken', 'Tender grilled chicken breast', 15.99, 'MAIN_COURSE', true), " +
//                "('Chocolate Cake', 'Rich chocolate cake with frosting', 6.99, 'DESSERT', true), " +
//                "('Garlic Bread', 'Toasted bread with garlic butter', 4.99, 'STARTER', true), " +
//                "('Beef Steak', 'Premium beef steak grilled to perfection', 22.99, 'MAIN_COURSE', true), " +
//                "('Ice Cream', 'Vanilla ice cream with toppings', 4.99, 'DESSERT', true)");
//            
//            System.out.println("Sample data initialized successfully!");
//            
//        } catch (Exception e) {
//            System.err.println("Error initializing sample data: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
    private void initializeSampleData() {
        try {
            // Check if tables already have data
            Integer tableCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM restaurant_tables", Integer.class);
            if (tableCount > 0) {
                System.out.println("Sample data already exists, skipping initialization.");
                return;
            }

            // Create 15 restaurant tables
            for (int i = 1; i <= 15; i++) {
                jdbcTemplate.update("INSERT INTO restaurant_tables (table_number, capacity, status) VALUES (?, ?, 'AVAILABLE')",
                        i, (i % 3) + 2); // Capacity between 2-4
            }

            // ✅ Fix category names to match enum values: STARTERS, MAIN_COURSE, DESSERTS
//            jdbcTemplate.update("INSERT INTO menu_items (name, description, price, category, available) VALUES " +
//                    "('Caesar Salad', 'Fresh romaine lettuce with caesar dressing', 8.99, 'STARTERS', true), " +
//                    "('Grilled Chicken', 'Tender grilled chicken breast', 15.99, 'MAIN_COURSE', true), " +
//                    "('Chocolate Cake', 'Rich chocolate cake with frosting', 6.99, 'DESSERTS', true), " +
//                    "('Garlic Bread', 'Toasted bread with garlic butter', 4.99, 'STARTERS', true), " +
//                    "('Beef Steak', 'Premium beef steak grilled to perfection', 22.99, 'MAIN_COURSE', true), " +
//                    "('Ice Cream', 'Vanilla ice cream with toppings', 4.99, 'DESSERTS', true)");
            
            jdbcTemplate.update("INSERT INTO menu_items (name, description, price, category, available) VALUES " +
                    "('Caesar Salad', 'Fresh romaine lettuce with caesar dressing', 8.99, 'STARTERS', true), " +
                    "('Grilled Chicken', 'Tender grilled chicken breast', 15.99, 'MAIN_COURSE', true), " +
                    "('Chocolate Cake', 'Rich chocolate cake with frosting', 6.99, 'DESSERTS', true), " +
                    "('Garlic Bread', 'Toasted bread with garlic butter', 4.99, 'STARTERS', true), " +
                    "('Beef Steak', 'Premium beef steak grilled to perfection', 22.99, 'MAIN_COURSE', true), " +
                    "('Ice Cream', 'Vanilla ice cream with toppings', 4.99, 'DESSERTS', true)");


            System.out.println("Sample data initialized successfully!");

        } catch (Exception e) {
            System.err.println("Error initializing sample data: " + e.getMessage());
            e.printStackTrace();
        }
    }

}
