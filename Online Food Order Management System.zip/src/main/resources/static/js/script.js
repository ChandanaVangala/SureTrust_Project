// Custom JavaScript for Restaurant Management System

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);

    // Add fade-in animation to cards
    var cards = document.querySelectorAll('.card');
    cards.forEach(function(card, index) {
        card.style.animationDelay = (index * 0.1) + 's';
        card.classList.add('fade-in');
    });

    // Form validation
    var forms = document.querySelectorAll('.needs-validation');
    forms.forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });

    // Quantity input controls
    var quantityInputs = document.querySelectorAll('input[type="number"]');
    quantityInputs.forEach(function(input) {
        input.addEventListener('change', function() {
            if (this.value < 1) {
                this.value = 1;
            }
        });
    });

    // Real-time clock for dashboard
    function updateClock() {
        var now = new Date();
        var timeString = now.toLocaleTimeString();
        var clockElements = document.querySelectorAll('.current-time');
        clockElements.forEach(function(element) {
            element.textContent = timeString;
        });
    }

    // Update clock every second
    setInterval(updateClock, 1000);
    updateClock(); // Initial call

    // Order status color coding
    var statusBadges = document.querySelectorAll('.status-badge');
    statusBadges.forEach(function(badge) {
        var status = badge.textContent.toLowerCase();
        badge.classList.remove('bg-primary', 'bg-secondary', 'bg-success', 'bg-danger', 'bg-warning', 'bg-info');
        
        switch(status) {
            case 'pending':
                badge.classList.add('bg-warning');
                break;
            case 'preparing':
                badge.classList.add('bg-info');
                break;
            case 'ready':
                badge.classList.add('bg-primary');
                break;
            case 'delivered':
                badge.classList.add('bg-success');
                break;
            case 'cancelled':
                badge.classList.add('bg-danger');
                break;
            default:
                badge.classList.add('bg-secondary');
        }
    });

    // Table status indicators
    var tableCards = document.querySelectorAll('.table-card');
    tableCards.forEach(function(card) {
        var status = card.dataset.status;
        if (status) {
            card.classList.add('table-' + status.toLowerCase());
        }
    });

    // Confirm dialogs for important actions
    var confirmButtons = document.querySelectorAll('[data-confirm]');
    confirmButtons.forEach(function(button) {
        button.addEventListener('click', function(event) {
            var message = this.dataset.confirm || 'Are you sure?';
            if (!confirm(message)) {
                event.preventDefault();
            }
        });
    });

    // Auto-refresh for waiter dashboard
    if (window.location.pathname.includes('/waiter/dashboard')) {
        setInterval(function() {
            // Only refresh if no modals are open
            if (!document.querySelector('.modal.show')) {
                location.reload();
            }
        }, 30000); // Refresh every 30 seconds
    }

    // Loading spinner for form submissions
    var forms = document.querySelectorAll('form');
    forms.forEach(function(form) {
        form.addEventListener('submit', function() {
            var submitButton = form.querySelector('button[type="submit"]');
            if (submitButton) {
                submitButton.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status"></span>Processing...';
                submitButton.disabled = true;
            }
        });
    });

    // Price calculation for orders
    function calculateOrderTotal() {
        var orderItems = document.querySelectorAll('.order-item');
        var total = 0;
        
        orderItems.forEach(function(item) {
            var price = parseFloat(item.dataset.price || 0);
            var quantity = parseInt(item.querySelector('.quantity-input')?.value || 0);
            total += price * quantity;
        });
        
        var totalElement = document.querySelector('.order-total');
        if (totalElement) {
            totalElement.textContent = '$' + total.toFixed(2);
        }
    }

    // Update total when quantities change
    var quantityInputs = document.querySelectorAll('.quantity-input');
    quantityInputs.forEach(function(input) {
        input.addEventListener('change', calculateOrderTotal);
    });

    // Initial calculation
    calculateOrderTotal();

    // Search functionality
    var searchInput = document.querySelector('#searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            var searchTerm = this.value.toLowerCase();
            var searchableItems = document.querySelectorAll('.searchable-item');
            
            searchableItems.forEach(function(item) {
                var text = item.textContent.toLowerCase();
                if (text.includes(searchTerm)) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    }

    // Smooth scrolling for anchor links
    var anchorLinks = document.querySelectorAll('a[href^="#"]');
    anchorLinks.forEach(function(link) {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            var target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Print functionality for bills
    var printButtons = document.querySelectorAll('.print-bill');
    printButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            window.print();
        });
    });

    // Dynamic time validation for table booking
    var dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(function(dateInput) {
        dateInput.addEventListener('change', function() {
            var selectedDate = new Date(this.value);
            var today = new Date();
            var timeInput = this.parentElement.parentElement.querySelector('input[type="time"]');
            
            if (timeInput && selectedDate.toDateString() === today.toDateString()) {
                var currentTime = today.getHours().toString().padStart(2, '0') + ':' + 
                                today.getMinutes().toString().padStart(2, '0');
                timeInput.min = currentTime;
            } else if (timeInput) {
                timeInput.removeAttribute('min');
            }
        });
    });
});

// Utility functions
function showLoading() {
    var loadingHtml = `
        <div class="spinner-overlay">
            <div class="spinner-border spinner-border-custom text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', loadingHtml);
}

function hideLoading() {
    var spinner = document.querySelector('.spinner-overlay');
    if (spinner) {
        spinner.remove();
    }
}

function showToast(message, type = 'info') {
    var toastHtml = `
        <div class="toast align-items-center text-white bg-${type} border-0" role="alert" style="position: fixed; top: 20px; right: 20px; z-index: 9999;">
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', toastHtml);
    
    var toastElement = document.querySelector('.toast:last-child');
    var toast = new bootstrap.Toast(toastElement);
    toast.show();
    
    // Remove toast element after it's hidden
    toastElement.addEventListener('hidden.bs.toast', function() {
        this.remove();
    });
}

// Export functions for global use
window.RestaurantApp = {
    showLoading: showLoading,
    hideLoading: hideLoading,
    showToast: showToast
};
